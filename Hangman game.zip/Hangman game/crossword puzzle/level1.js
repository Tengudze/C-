const words = [
    { word: "JAVASCRIPT", color: "#ff6347", found: false },
    { word: "HTML", color: "#4682b4", found: false },
    { word: "CSS", color: "#32cd32", found: false },
    { word: "NODE", color: "#ffa500", found: false },
    { word: "REACT", color: "#9370db", found: false }
    /* { word: "CODE", color: "#0000FF", found: false }
    { word: "FUNCTION", color: "#FFD700", found: false },
    { word: "RANDOM", color: "#008000", found: false },
    { word: "ARRAY", color: "#FFB6C1", found: false }*/
];

const gridSize = 10;
const grid = Array.from(Array(gridSize), () => Array(gridSize).fill(''));
let selectedCells = [];

function placeWord(word) {
    const directions = [
        { x: 1, y: 0 },  // Horizontal
        { x: 0, y: 1 },  // Vertical
        { x: 1, y: 1 },  // Diagonal down-right
        { x: 1, y: -1 },  // Diagonal up-right
        { x: -1, y: 0} //backwards
    ];
    const dir = directions[Math.floor(Math.random() * directions.length)];
    let placed = false;

    while (!placed) {
        const startX = Math.floor(Math.random() * gridSize);
        const startY = Math.floor(Math.random() * gridSize);

        let endX = startX + dir.x * (word.word.length - 1);
        let endY = startY + dir.y * (word.word.length - 1);

        if (endX >= 0 && endX < gridSize && endY >= 0 && endY < gridSize) {
            let canPlace = true;
            for (let i = 0; i < word.word.length; i++) {
                if (grid[startY + dir.y * i][startX + dir.x * i] !== '') {
                    canPlace = false;
                    break;
                }
            }
            if (canPlace) {
                for (let i = 0; i < word.word.length; i++) {
                    grid[startY + dir.y * i][startX + dir.x * i] = word.word[i];
                }
                placed = true;
            }
        }
    }
}

function fillEmptyCells() {
    for (let y = 0; y < gridSize; y++) {
        for (let x = 0; x < gridSize; x++) {
            if (grid[y][x] === '') {
                grid[y][x] = String.fromCharCode(65 + Math.floor(Math.random() * 26)); // Random letter A-Z
            }
        }
    }
}

function createGrid() {
    const gridElement = document.getElementById('grid');
    grid.forEach((row) => {
        row.forEach((letter) => {
            const cell = document.createElement('div');
            cell.className = 'cell';
            cell.textContent = letter;
            cell.addEventListener('click', () => {
                toggleCellSelection(cell);
            });
            gridElement.appendChild(cell);
        });
    });

    const checkButton = document.createElement('button');
    checkButton.textContent = 'Check Word';
    checkButton.style.marginTop = '10px';
    checkButton.addEventListener('click', checkSelectedWord);
    document.body.appendChild(checkButton);
}

function toggleCellSelection(cell) {
    if (!cell.classList.contains('found')) {
        cell.classList.toggle('selected');
        if (cell.classList.contains('selected')) {
            selectedCells.push(cell);
        } else {
            selectedCells = selectedCells.filter(c => c !== cell);
        }
    }
}

let foundWordsCount = 0; // Track how many words have been found

function displayWordList(){
    const wordListElement = document.getElementById('word-list');
    words.forEach(word => {
        const li = document.createElement('li');
        li.textContent = word.word;
        if (word.found){
            li.classList.add('found'); // Mark as found if already found
        }
        wordListElement.appendChild(li);
    });
}

function checkSelectedWord(){
    const selectedWord = selectedCells.map(cell => cell.textContent).join('');
    const wordObj = words.find(word => word.word === selectedWord);

    if (wordObj) {
        selectedCells.forEach(cell => {
            cell.style.backgroundColor = wordObj.color;
            cell.classList.add('found');
        });
        alert(`You found: ${selectedWord}`);

        // Increment found words count
        if (!wordObj.found) {
            foundWordsCount++;
            wordObj.found = true; // Mark this word as found
            updateWordListDisplay(wordObj.word); // Update the word list
        }
    } else {
        alert('No match found!');
    }

    // Clear selection
    selectedCells.forEach(cell => cell.classList.remove('selected'));
    selectedCells = [];

    // Check if all words are found
    if (foundWordsCount === words.length) {
        document.getElementById('next-level').style.display = 'block';
    }
}
function updateWordListDisplay(foundWord) {
    const wordListItems = document.querySelectorAll('#word-list li');
    wordListItems.forEach(item => {
        if (item.textContent === foundWord) {
            item.classList.add('found'); // Add the found class to the list item
        }
    });
}
// Initialize the word list display
displayWordList();

// Initialize found status for words
words.forEach(word => { word.found = false; });

// Next Level Button Functionality
document.getElementById('next-level').addEventListener('click', () => {
    window.location.href = 'level_2.html'; // Link to the next level
});

// Start the game
words.forEach(placeWord);
fillEmptyCells();
createGrid();