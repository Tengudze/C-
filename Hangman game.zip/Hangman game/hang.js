const words = [
    ["apple", "banana", "cherry", "date", "elderberry"],
    ["orange", "kiwi", "grapefruit", "mango", "papaya"],
    ["strawberry", "blueberry", "blackberry", "raspberry", "cranberry"]
];
let level = 0;
let wordIndex = 0;
let word = words[level][wordIndex];
let guessedLetters = [];
let attempts = 6;
let correctGuesses = 0;

function displayWord() {
    let display = "";
    for (let letter of word) {
        if (guessedLetters.includes(letter)) {
            display += letter + " ";
        } else {

            display += "_ ";
        }
    }
    document.getElementById("word").innerText = display;
}

function checkLetter(letter) {
    if (!guessedLetters.includes(letter)) {
        guessedLetters.push(letter);
        if (!word.includes(letter)) {
            attempts--;
        }
    }

    if (attempts === 0) {
        alert("You're out of attempts. The word was: " + word);
        resetGame();
    }


    if (word.split('').every(letter => guessedLetters.includes(letter))) {
        correctGuesses++;
        if (correctGuesses === 5) {
            level++;
            wordIndex = 0;
            word = words[level][wordIndex];
            guessedLetters = [];
            attempts = 6;
            correctGuesses = 0;
            alert("Congratulations! You've reached Level " + level);
        } else {
            nextWord();
        }
    }

    displayWord();
}

function giveHint() {
    const hiddenLetters = word.split('').filter(letter => !guessedLetters.includes(letter));
    if (hiddenLetters.length > 0) {
        const hintLetter = hiddenLetters[Math.floor(Math.random() * hiddenLetters.length)];
        checkLetter(hintLetter);
    }
}

function nextWord() {
    wordIndex++;
    if (wordIndex >= words[level].length) {
        level++;
        wordIndex = 0;
    }
    word = words[level][wordIndex];
    guessedLetters = [];
    attempts = 6;

    displayWord();
}

function resetGame() {
    level = 0;
    wordIndex = 0;
    word = words[level][wordIndex];
    guessedLetters = [];
    attempts = 6;
    correctGuesses = 0;
    displayWord();
}

displayWord();
document.addEventListener('keypress', event => {
    const letter = String.fromCharCode(event.keyCode).toLowerCase();
    if (/[a-z]/.test(letter)) {
        checkLetter(letter);

    }
});

document.getElementById("hint").addEventListener('click', giveHint);
